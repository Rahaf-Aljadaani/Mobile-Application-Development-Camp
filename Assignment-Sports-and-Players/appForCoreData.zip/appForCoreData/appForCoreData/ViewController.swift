//
//  ViewController.swift
//  appForCoreData
//
//  Created by administrator on 01/11/2021.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    var index : IndexPath!
    var items : [NSManagedObject] = []
    @IBOutlet weak var tabelview: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        title = "The List"
        tabelview.dataSource = self
        tabelview.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        
    }
    
    //////////////////////
    
    override func viewWillAppear(_ animated: Bool) {
      super.viewWillAppear(animated)
      
      //1
      guard let appDelegate =
        UIApplication.shared.delegate as? AppDelegate else {
          return
      }
      
      let managedContext =
        appDelegate.persistentContainer.viewContext
      
      //2
      let fetchRequest =
        NSFetchRequest<NSManagedObject>(entityName: "Sports")
      
      //3
      do {
        items = try managedContext.fetch(fetchRequest)
      } catch let error as NSError {
        print("Could not fetch. \(error), \(error.userInfo)")
      }
    }


    // Implement the addName IBAction
    @IBAction func addName(_ sender: UIBarButtonItem) {
      
      let alert = UIAlertController(title: "New Sport",message: "Add a new sport", preferredStyle: .alert)
      
      let saveAction = UIAlertAction(title: "Save", style: .default) {
        [unowned self] action in
                                      
        guard let textField = alert.textFields?.first,
          let nameToSave = textField.text else {
            return
        }
        
        self.save(name: nameToSave)
      //  self.items.append(nameToSave)
        self.tabelview.reloadData()
      }
      
      let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
      
      alert.addTextField()
      
      alert.addAction(saveAction)
      alert.addAction(cancelAction)
      
      present(alert, animated: true)
    }
    
    ////////////////////////////////////////////////////
    func save(name: String) {
      
      guard let appDelegate =
        UIApplication.shared.delegate as? AppDelegate else {
        return
      }
      
    
      let managedContext =  appDelegate.persistentContainer.viewContext
      
     
      let entity = NSEntityDescription.entity(forEntityName: "Sports",
                                   in: managedContext)!
      
      let person = NSManagedObject(entity: entity, insertInto: managedContext)
      
    
      person.setValue(name, forKeyPath: "name")
    
        
      do {
        try managedContext.save()
        items.append(person)
      } catch let error as NSError {
        print("Could not save. \(error), \(error.userInfo)")
      }
    }
    func delet(_ obj : NSManagedObject) {
      
      guard let appDelegate =
        UIApplication.shared.delegate as? AppDelegate else {
        return
      }
      
    
      let managedContext =  appDelegate.persistentContainer.viewContext
      
     
      let entity = NSEntityDescription.entity(forEntityName: "Sports",
                                   in: managedContext)!
      
      let person = NSManagedObject(entity: entity, insertInto: managedContext)
     
      do {
        try managedContext.delete(obj)
        items.append(person)
      } catch let error as NSError {
        print("Could not save. \(error), \(error.userInfo)")
      }
    }
}



extension ViewController: UITableViewDataSource {
  
  func tableView(_ tableView: UITableView,
                 numberOfRowsInSection section: Int) -> Int {
    return items.count
  }
  
  func tableView(_ tableView: UITableView,cellForRowAt indexPath: IndexPath)  -> UITableViewCell {

    let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! customCellTableViewCell
    index = indexPath
    let sport = items[indexPath.row]
    cell.labeltext?.text = sport.value(forKeyPath: "name") as? String
    return cell
  }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
    
        self.items.remove(at: indexPath.row)
        delet(items.remove(at: indexPath.row))
        self.tabelview.reloadData()
    }

}


extension ViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate  {
   
    // get results of user taking picture or selecting from camera roll
    func presentPhotoActionSheet(){
        let actionSheet = UIAlertController(title: "Profile Picture", message: "How would you like to select a picture?", preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        actionSheet.addAction(UIAlertAction(title: "Take Photo", style: .default, handler: { [weak self] _ in
            self?.presentCamera()
        }))
        actionSheet.addAction(UIAlertAction(title: "Choose Photo", style: .default, handler: { [weak self] _ in
            self?.presentPhotoPicker()
        }))
        
        present(actionSheet, animated: true)
    }
    func presentCamera() {
        let vc = UIImagePickerController()
        vc.sourceType = .camera
        vc.delegate = self
        vc.allowsEditing = true
        present(vc, animated: true)
    }
    func presentPhotoPicker() {
        let vc = UIImagePickerController()
        vc.sourceType = .photoLibrary
        vc.delegate = self
        vc.allowsEditing = true
        present(vc, animated: true)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        // take a photo or select a photo
        
        // action sheet - take photo or choose photo
        picker.dismiss(animated: true, completion: nil)
        print(info)
        
        guard let selectedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage else {
            return
        }
        
        
    //    customCellTableViewCell.imageview.setImage(selectedImage, for: .normal)
        
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
}

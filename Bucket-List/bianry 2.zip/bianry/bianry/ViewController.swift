//
//  ViewController.swift
//  bianry
//
//  Created by administrator on 06/10/2021.
//

import UIKit
import CoreData

class ViewController: UIViewController , UITableViewDataSource,UITableViewDelegate {
    static var NewText : String = ""

    static var items : [String] = ["Rahaf","Remm"]
    @IBOutlet weak var tableview: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
   
        tableview.dataSource = self
     //   items.append(ViewController.NewText)
    //    readItem()
      //  tableview.delegate = self
    }
  /*
    weak var delegate: CancelButtonDelegate?
      @IBAction func cancelBarButtonPressed(_ sender: UIBarButtonItem) {
          delegate?.cancelButtonPressed(by: self)
      }*/
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ViewController.items.count
    }

func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

      let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! customCell
    cell.textlabel.text = String(ViewController.items[indexPath.row])
    //cell.delegate = self
    
      return cell
  }
    
    //weak var delegate_add: AddItemTableViewControllerDelegate?
       @IBOutlet weak var itemTextField: UITextField!
       @IBAction func cancelBarButtonPressed(_ sender: UIBarButtonItem) {
   //     delegate_add?.addItemViewController(self, didPressCancelButton: sender)
       }
       @IBAction func doneBarButtonPressed(_ sender: UIBarButtonItem) {
     //   delegate_add?.addItemViewController(self, didFinishAddingItem: itemTextField.text!)
       }
  
    
}


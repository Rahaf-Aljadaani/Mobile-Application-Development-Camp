
import UIKit
/*
protocol CancelButtonDelegate: class {
    func cancelButtonPressed(by controller: UIViewController)
}

protocol AddItemTableViewControllerDelegate: class {
    func addItemViewController(_ controller: ViewController, didFinishAddingItem item: String)
    func addItemViewController(_ controller: ViewController, didPressCancelButton button: UIBarButtonItem) // Taken from CancelButtonDelegate file, and altered to match pattern.
    // NOTE: You will need to update AddItemTableViewController to make the Cancel Button work
}


, CancelButtonDelegate ,  AddItemTableViewControllerDelegate {
    
    func addItemViewController(_ controller: ViewController, didPressCancelButton button: UIBarButtonItem) {
        print("fff")
    }
    
    // ...
    func addItemViewController(_ controller: ViewController, didFinishAddingItem item: String) {
        dismiss(animated: true, completion: nil)
    //    items.append(item)
        tableView.reloadData()
    }
    // ...
    // ...
    func cancelButtonPressed(by controller: UIViewController) {
        dismiss(animated: true, completion: nil)
    }
    */
 
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

class BucketListViewController: UITableViewController {
    /*
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
          if segue.identifier == "Add" {//AddNewMission
              let navigationController = segue.destination as! UINavigationController
              let controller = navigationController.topViewController as! ViewController
             // controller.delegate_add = self
          }
      }*/

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    @IBAction func censelGoBack(_ sender: Any) {
     //   cancelButtonPressed(by: <#UIViewController#>)
    }
    
    @IBAction func saveChang(_ sender: Any) {
     //   let cell = tableView.dequeueReusableCell(withIdentifier: "cellnew", for: indexPath) as!customCell
    //    if let task = "newtexttext"{
            ViewController.items.append("task")
       // ViewController.items.
           // ViewController.NewText = task
                  // addItem(name: task)
            //   }
    }
}

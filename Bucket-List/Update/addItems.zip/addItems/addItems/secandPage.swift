//
//  secandPage.swift
//  addItems
//
//  Created by administrator on 12/10/2021.
//

import UIKit

class secandPage: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
   /***
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "addnew" {
                
           //     if let x = textField.text {
                  //  ViewController.Items.append(x)}
                
            } else if segue.identifier == "EditItemSegue" {
                
                // Set Self as Destination Delegate AND Set Item / IndexPath Using Sender
            }
        }
    @IBOutlet weak var textField: UITextField!
    
    @IBAction func savebutton(_ sender: Any) {
        if let x = textField.text {
        //    ViewController.Items.append(x)}
    }
    */
}

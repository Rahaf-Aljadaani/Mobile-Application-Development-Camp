

import UIKit
import CoreData

class Pinkpage: UITableViewController {
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    @IBOutlet weak var textFeild: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    @IBAction func saveItem(_ sender: Any) {
        if let newText = textFeild.text {
            createItem(name: newText)
        }
    }
    func createItem(name: String) {
       let newItem = AddItemList(context: context)
        newItem.item = name
        do{
            try context.save()
        }
        catch{
            print("Error")
        }
    }

}

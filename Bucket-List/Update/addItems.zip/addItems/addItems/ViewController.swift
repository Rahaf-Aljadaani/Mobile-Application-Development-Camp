import UIKit
import CoreData
class ViewController: UIViewController   , UITableViewDataSource {
   
    var itemplase : AddItemList
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    @IBOutlet weak var tabelview: UITableView!

   private var Items : [AddItemList] = []
    
    //-----------------------------------------------------
   
    //---------------------------------------
    
    override func viewDidLoad() {
        super.viewDidLoad()
            tabelview.dataSource = self
           // tabelview.delegate = self
    }
 
    //------------------- tabelview sttaf
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Items.count  // returning the number  of elements in  data array
        }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tabelview.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
            cell.textLabel?.text = Items[indexPath.row]
        itemplase = Items[indexPath.row]
// tabelview.reloadData()
            return cell
        }
    
    
    //------------------------ buttons
    @IBAction func openAddView(_ sender: Any) {
              if let controller = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Pinkpage") as? Pinkpage {
              self.navigationController?.pushViewController(controller, animated: true)
              }
    }
    
    @IBAction func UpdatButton(_ sender: Any) {
        if let controller = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Pinkpage") as? Pinkpage {
        self.navigationController?.pushViewController(controller, animated: true)
        }
        
        updateItem(olditem: itemplase, newitem: Items.pop)
    }
    
    
    //------------------------ for core data
    func getAllItem () {
        do {
            let items = try context.fetch(AddItemList.fetchRequest())
        }
        catch {
            print("Error")
        }
    }
  
    func deleteItem (item: AddItemList) {
        context.delete(item)
        do{
            try context.save()
        }
        catch{
            print("Error")
        }
    }
    func updateItem (olditem: AddItemList , newitem: String) {
        olditem.item = newitem
        do{
            try context.save()
        }
        catch{
            print("Error")
        }
    }
    //---------------------------------------------------

    
}

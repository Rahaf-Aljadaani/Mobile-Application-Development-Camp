//
//  secandPage.swift
//  NorthApp
//
//  Created by administrator on 07/10/2021.
//

import UIKit


class secandPage: UIViewController  {
 
    var NameOfSide : String?
   
    override func viewDidLoad() {
        super.viewDidLoad()
      //  x.deleget = self
        textLabel.text = NameOfSide
        // Do any additional setup after loading the view.
    }
    

    @IBOutlet weak var textLabel: UILabel!
    
    
    
    @IBAction func returnBoutton(_ sender: Any) {
       dismiss(animated: true, completion: nil)
    }
    
}



//
//  ViewController.swift
//  NorthApp
//
//  Created by administrator on 07/10/2021.
//

import UIKit



class ViewController: UIViewController {
    
    var NameOfSide : String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destination = segue.destination as! secandPage
        destination.NameOfSide = NameOfSide
    }
    @IBAction func SuothButton(_ sender: Any) {
      NameOfSide = "South"
    
        
    }
    @IBAction func NorthButton(_ sender: Any) {
        NameOfSide = "North"
    }
    
    @IBAction func WestButton(_ sender: Any) {
        NameOfSide = "Wast"
    }
    @IBAction func EastButton(_ sender: Any) {
        NameOfSide = "East"
    }
    
    
}


//
//  customCell.swift
//  bianry
//
//  Created by administrator on 06/10/2021.
//

import UIKit

class customCell: UITableViewCell {
    @IBOutlet weak var totalLabel: UILabel!
    var total: Double = 0
    var numberNow : Double = 0
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    func takeTotalLabel(_ tot: UILabel) {
       totalLabel = tot
    }

    @IBOutlet weak var textlabel: UILabel!
    @IBAction func subNum(_ sender: Any) {
            if let x = textlabel.text{
            numberNow = Double(x)!
                total -= numberNow }
            totalLabel.text = String(total)        
    }
    @IBAction func addNum(_ sender: Any) {
            if let x = textlabel.text{
            numberNow = Double(x)!
                total += numberNow }
            totalLabel.text = String(total)
       
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

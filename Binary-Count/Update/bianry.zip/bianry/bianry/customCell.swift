//
//  customCell.swift
//  bianry
//
//  Created by administrator on 06/10/2021.
//

import UIKit
protocol costomdelegate : AnyObject {
    func addToTotal(total: Int)
    func subToTotal(total: Int)

}

class customCell: UITableViewCell {
    

 //   var power : Int?
    weak var delegate : costomdelegate?
    var total: Int = 0
    var numberNow : Int = 0
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
   

    @IBOutlet weak var textlabel: UILabel!
    
    
    @IBAction func subNum(_ sender: Any) {
            if let x = textlabel.text{
            numberNow = Int(x)!
                delegate?.addToTotal(total: numberNow)}
           
    }
    @IBAction func addNum(_ sender: Any) {
            if let x = textlabel.text{
            numberNow = Int(x)!
                total += numberNow
                delegate?.subToTotal(total: numberNow)
            }
       
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

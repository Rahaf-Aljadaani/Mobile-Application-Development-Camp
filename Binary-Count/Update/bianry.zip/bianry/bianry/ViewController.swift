//
//  ViewController.swift
//  bianry
//
//  Created by administrator on 06/10/2021.
//

import UIKit

class ViewController: UIViewController , UITableViewDataSource,UITableViewDelegate {
    @IBOutlet weak var totalLabel: UILabel!
    var numberOfPower : [Int] = []
    @IBOutlet weak var tableview: UITableView!
    
    var totalAmount: Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        var y : Int = 1
        numberOfPower.append(1)
        for _ in 1...16 {
            numberOfPower.append(10*y)
            y *= 10
        }
        totalLabel.text = "Total : \(totalAmount)"
        tableview.dataSource = self
      //  tableview.delegate = self
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return numberOfPower.count  // returning the number  of elements in  data array
    }

func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

      let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! customCell
      cell.textlabel.text = String(numberOfPower[indexPath.row])
   // cell.power = numberOfPower[indexPath.row]
    cell.delegate = self
   // cell.textLabel?.text = "\(numberOfPower[indexPath.row])"
    
      return cell
  }
}
extension ViewController : costomdelegate {
    func addToTotal(total: Int){
        self.totalAmount += total
        totalLabel.text = "Total = \(totalAmount)"
    }
    func subToTotal(total: Int){
        self.totalAmount -= total
        totalLabel.text = "Total = \(totalAmount)"
    }
}

//////////////////////////////////////////////////////////////
/*

extension ViewController: UITableViewDataSource,UITableViewDelegate {
  
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return numberOfPower.count  // returning the number  of elements in  data array
        }
   
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

          let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! customCell
          cell.textlabel.text = String(numberOfPower[indexPath.row])
          return cell
      }
  
/*
func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

    print("Section: \(indexPath.section) and Row: \(indexPath.row)")
    numberOfPower.remove(at: indexPath.row)
    tableview.reloadData()
}*/

    }


*/

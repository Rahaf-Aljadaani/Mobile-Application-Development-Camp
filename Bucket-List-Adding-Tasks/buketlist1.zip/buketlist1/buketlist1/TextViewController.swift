//
//  AddTextViewController.swift
//  buketlist1
//
//  Created by administrator on 25/10/2021.
//

import UIKit

class TextViewController: UIViewController {
    var delog: ViewController?
    @IBOutlet weak var TextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func doSomthing(_ sender: Any) {
        let NewText = TextField.text!
        
        
        TaskModel.addTaskWithObjective(objective: NewText, completionHandler: {
            data, response, error in
            if data != nil {
                do {
                    let tasks = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
                    
                    DispatchQueue.main.async {
                        self.delog?.task.append(tasks)
                        self.delog?.tabelview.reloadData()
                        let _ = self.navigationController?.viewControllers.popLast()
                  }
                    
                }
               catch {
                  print("Something went wrong")
              }
            }
           
  })
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

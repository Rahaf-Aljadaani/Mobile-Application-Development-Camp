//
//  ViewController.swift
//  table
//
//  Created by administrator on 04/10/2021.
//

import UIKit

class ViewController: UIViewController {
    var item : [String] = []
    @IBOutlet weak var tabelview: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tabelview.dataSource = self
        //tabelview.delegate = self
        
       // self.tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")

    }

  
    @IBOutlet weak var textfild: UITextField!
    
    @IBAction func actionbuton(_ sender: Any) {

        if let t = textfild.text {
            textfild.text = ""
            item.append(t)
            tabelview.reloadData()
        }
        
    }
 
}

extension ViewController: UITableViewDataSource {
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return item.count  // returning the number  of elements in  data array
        }
   
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

          let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
          cell.textLabel?.text = item[indexPath.row]
        cell.detailTextLabel?.text = String(item[0])
          return cell
      }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       // let cell = tableView.cellForRow(at: indexPath)
       // cell?.contentView.backgroundColor = UIColor.blue
        print("Section: \(indexPath.section) and Row: \(indexPath.row)")
        item.remove(at: indexPath.row)
        tableView.reloadData()
    }
  }


//
//  ViewController.swift
//  tipster
//
//  Created by administrator on 30/09/2021.
//

import UIKit

class ViewController: UIViewController {
    var num : String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var number: UILabel!
    var cheak : Bool = false
    
  
    @IBAction func adddot(_ sender: Any) {
        num += "."
        number.text = num
     
            }
    
    @IBAction func add0(_ sender: Any) {
        if cheak == true {
            num = "0"
            number.text = num
            cheak = false        }
        else{
        num += "0"
            number.text = num}
        
    }
    @IBAction func add1(_ sender: Any) {
        if cheak == true {
            num = "1"
            number.text = num
            cheak = false        }
        else{
        num += "1"
            number.text = num}
        
    }
    @IBAction func add2(_ sender: Any) {
        if cheak == true {
            num = "2"
            number.text = num
            cheak = false        }
        else{
        num += "2"
            number.text = num}
    
        
    }
    
    @IBAction func add3(_ sender: Any) {
        if cheak == true {
            num = "3"
            number.text = num
            cheak = false        }
        else{
        num += "3"
            number.text = num}
      
        
    }
    
    @IBAction func add4(_ sender: Any) {
        if cheak == true {
            num = "4"
            number.text = num
            cheak = false        }
        else{
        num += "4"
            number.text = num}
      
            }
    @IBAction func add5(_ sender: Any) {
        if cheak == true {
            num = "5"
            number.text = num
            cheak = false
        }
        else{
        num += "5"
            number.text = num}
      
            }
    @IBAction func add6(_ sender: Any) {
        if cheak == true {
            num = "6"
            number.text = num
            cheak = false
        }
        else{
        num += "6"
            number.text = num}
      
            
        
            }
    
    @IBAction func add7(_ sender: Any) {
        if cheak == true {
            num = "7"
            number.text = num
            cheak = false
        }
        else{
        num += "7"
            number.text = num}
      
            
      
            }
    @IBAction func add8(_ sender: Any) {
        
        if cheak == true {
            num = "8"
            number.text = num
            cheak = false
        }
        else{
        num += "8"
            number.text = num}
      
            
         }
    @IBAction func add9(_ sender: Any) {
        if cheak == true {
            num = "9"
            number.text = num
            cheak = false
        }
        else{
        num += "9"
            number.text = num}
    
      
    }
/////////////////////////////////////////////////////////////
    ///////////////////////////////
    ////////////////////////////////////////////
    
    var x : Int = 0
    var firstNumber: Bool = true
    var whichOpration : Int = 0
    
    @IBAction func sub(_ sender: Any) {
        whichOpration = 1
        cheak = true
        if(firstNumber == false){
        if let t = Int(num){
            x = x - t
            number.text = String(x)
            num = String(x)
            
        }}
        else {
            if let t = Int(num){
                x = t - x
                number.text = String(x)
                num = String(x)
                firstNumber = false
                
            }
        }
      
        
    }
    
    
    @IBAction func sum(_ sender: Any) {
        whichOpration = 2
        cheak = true
        if let t = Int(num){
            x = x + t
            number.text = String(x)
            num = String(x)
            
        }
     
    }
    
    @IBAction func mult(_ sender: Any) {
        whichOpration = 3
        cheak = true
        if(firstNumber == false){
        if let t = Int(num){
            x = x * t
            number.text = String(x)
            num = String(x)
            
        }}
        else {
            if let t = Int(num){
                x = t
                number.text = String(x)
                num = String(x)
                firstNumber = false
                
            }
        }    }
    
    @IBAction func diff(_ sender: Any) {
        whichOpration = 4
        cheak = true
        if(firstNumber == false){
        if let t = Int(num){
            x = x / t
            number.text = String(x)
            num = String(x)
            
        }}
        else {
            if let t = Int(num){
                x = t / x
                number.text = String(x)
                num = String(x)
                firstNumber = false
                
            }
        }    }
    @IBAction func mod(_ sender: Any) {
        whichOpration = 5
        cheak = true
        if(firstNumber == false){
        if let t = Int(num){
            x = x % t
            number.text = String(x)
            num = String(x)
            
        }}
        else {
            if let t = Int(num){
                x = t % x
                number.text = String(x)
                num = String(x)
                firstNumber = false
                
            }
        }
    }
    
    @IBAction func sigan(_ sender: Any) {
    }
    var y : Int = 0
    @IBAction func resalt(_ sender: Any) {
        if let t = Int(num){
            y = t
          }
        firstNumber = true
        switch whichOpration {
        case 1:
            number.text = String(x-y)
            num = String(x-y)
            x = x-y
        case 2:
            number.text = String(x+y)
            num = String(x+y)
            x = x+y
        case 3:
            number.text = String(x*y)
            num = String(x*y)
            x = x*y
        case 4:
            number.text = String(x/y)
            num = String(x/y)
            x = x/y
        case 5:
            number.text = String(x%y)
            num = String(x%y)
            x = x%y
        default :
            print ("error")
        }
        
        
       
    }
    @IBAction func clear(_ sender: Any) {
        number.text = ""
        num = ""
        x = 0
        firstNumber = true
    
    }
       
        
    
    
    
}


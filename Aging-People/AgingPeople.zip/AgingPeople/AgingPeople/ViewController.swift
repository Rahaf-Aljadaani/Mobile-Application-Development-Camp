//
//  ViewController.swift
//  AgingPeople
//
//  Created by administrator on 04/10/2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableview: UITableView!
    var item : [String] = ["Rahaf","kevin","Danny","Rodrigo", "Ashish","hissan","Ahmad","Pulkit","Reem","Hanof","Mayar","Roba"]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableview.dataSource = self
      //  tableview.delegate = self
        
    }
    
    }
    


extension ViewController: UITableViewDataSource {
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return item.count  // returning the number  of elements in  data array
        }
   
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

          let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
          cell.textLabel?.text = item[indexPath.row]
        let random : Int = Int.random(in: 5...95)
        let detal : String = String(random) + " years old"
        cell.detailTextLabel?.text = String(detal)
          return cell
      }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       // let cell = tableView.cellForRow(at: indexPath)
       // cell?.contentView.backgroundColor = UIColor.blue
        print("Section: \(indexPath.section) and Row: \(indexPath.row)")
        item.remove(at: indexPath.row)
        tableView.reloadData()
    }
  }

//
//  ViewController.swift
//  tipster
//
//  Created by administrator on 30/09/2021.
//

import UIKit

class ViewController: UIViewController {
    var num : String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var number: UILabel!
    
    @IBOutlet weak var tep1: UILabel!
    @IBOutlet weak var tip2: UILabel!
    @IBOutlet weak var tip3: UILabel!
    

    @IBOutlet weak var t1: UILabel!
    @IBOutlet weak var t2: UILabel!
    @IBOutlet weak var t3: UILabel!
    @IBOutlet weak var t4: UILabel!
    @IBOutlet weak var t5: UILabel!
    @IBOutlet weak var t6: UILabel!

    @IBOutlet weak var s1: UISlider!
    
    @IBOutlet weak var s2: UISlider!
    
    @IBAction func addslider(_ sender: UISlider) {
        x += (Double(sender.value) * 10)
        y += (Double(sender.value) * 10)
        z += (Double(sender.value) * 10)
    }
  
    
    @IBAction func slider2(_ sender: Any) {
    }
    
    var x :Double = 0.10
    var y :Double = 0.15
    var z :Double = 0.20
    
    @IBAction func clear(_ sender: Any) {
        number.text = "0"
        num = ""
        t1.text = "0"
        t2.text = "0"
        t3.text = "0"
        t4.text = "0"
        t5.text = "0"
        t6.text = "0"
    }
    @IBAction func adddot(_ sender: Any) {
        num += "."
        number.text = num
     
            }
    
    @IBAction func add0(_ sender: Any) {
        num += "0"
        number.text = num
        let myDouble = Double(num)
        if let d = myDouble {
            let temp : Double = d * x
            t1.text = String(format: "%0.3f",temp)
            let temp2 : Double = temp + d
            t4.text = String(format: "%0.3f",temp2)
            
        }
        
        let myDouble1 = Double(num)
        if let d = myDouble1 {
            let temp : Double = d * y
            t2.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t5.text = String(format: "%0.3f",temp2)
        }
        
        let myDouble2 = Double(num)
        if let d = myDouble2 {
            let temp : Double = d * z
            t3.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t6.text = String(format: "%0.3f",temp2)
        }
        
    }
    @IBAction func add1(_ sender: Any) {
        num += "1"
        number.text = num
        let myDouble = Double(num)
        if let d = myDouble {
            let temp : Double = d * x
            t1.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t4.text = String(format: "%0.3f",temp2)        }
        
        let myDouble1 = Double(num)
        if let d = myDouble1 {
            let temp : Double = d * y
            t2.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t5.text = String(format: "%0.3f",temp2)
        }
        
        let myDouble2 = Double(num)
        if let d = myDouble2 {
            let temp : Double = d * z
            t3.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t6.text = String(format: "%0.3f",temp2)
        }
        
    }
    @IBAction func add2(_ sender: Any) {
        num += "2"
        number.text = num
        let myDouble = Double(num)
        if let d = myDouble {
            let temp : Double = d * x
            t1.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t4.text = String(format: "%0.3f",temp2)
        }
        
        let myDouble1 = Double(num)
        if let d = myDouble1 {
            let temp : Double = d * y
            t2.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t5.text = String(format: "%0.3f",temp2)
        }
        
        let myDouble2 = Double(num)
        if let d = myDouble2 {
            let temp : Double = d * z
            t3.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t6.text = String(format: "%0.3f",temp2)
        }
        
    }
    
    @IBAction func add3(_ sender: Any) {
        num += "3"
        number.text = num
        let myDouble = Double(num)
        if let d = myDouble {
            let temp : Double = d * x
            t1.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t4.text = String(format: "%0.3f",temp2)
        }
        
        let myDouble1 = Double(num)
        if let d = myDouble1 {
            let temp : Double = d * y
            t2.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t5.text = String(format: "%0.3f",temp2)
        }
        
        let myDouble2 = Double(num)
        if let d = myDouble2 {
            let temp : Double = d * z
            t3.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t6.text = String(format: "%0.3f",temp2)
        }
        
    }
    
    @IBAction func add4(_ sender: Any) {
        num += "4"
        number.text = num
        let myDouble = Double(num)
        if let d = myDouble {
            let temp : Double = d * x
            t1.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t4.text = String(format: "%0.3f",temp2)
        }
        
        let myDouble1 = Double(num)
        if let d = myDouble1 {
            let temp : Double = d * y
            t2.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t5.text = String(format: "%0.3f",temp2)
        }
        
        let myDouble2 = Double(num)
        if let d = myDouble2 {
            let temp : Double = d * z
            t3.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t6.text = String(format: "%0.3f",temp2)
        }
            }
    @IBAction func add5(_ sender: Any) {
        num += "5"
        number.text = num
        let myDouble = Double(num)
        if let d = myDouble {
            let temp : Double = d * x
            t1.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t4.text = String(format: "%0.3f",temp2)
        }
        
        let myDouble1 = Double(num)
        if let d = myDouble1 {
            let temp : Double = d * y
            t2.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t5.text = String(format: "%0.3f",temp2)
        }
        
        let myDouble2 = Double(num)
        if let d = myDouble2 {
            let temp : Double = d * z
            t3.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t6.text = String(format: "%0.3f",temp2)
        }
            }
    @IBAction func add6(_ sender: Any) {
        num += "6"
        number.text = num
        let myDouble = Double(num)
        if let d = myDouble {
            let temp : Double = d * x
            t1.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t4.text = String(format: "%0.3f",temp2)
        }
        
        let myDouble1 = Double(num)
        if let d = myDouble1 {
            let temp : Double = d * y
            t2.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t5.text = String(format: "%0.3f",temp2)
        }
        
        let myDouble2 = Double(num)
        if let d = myDouble2 {
            let temp : Double = d * z
            t3.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t6.text = String(format: "%0.3f",temp2)        }
            }
    
    @IBAction func add7(_ sender: Any) {
        num += "7"
        number.text = num
        let myDouble = Double(num)
        if let d = myDouble {
            let temp : Double = d * x
            t1.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t4.text = String(format: "%0.3f",temp2)
        }
        
        let myDouble1 = Double(num)
        if let d = myDouble1 {
            let temp : Double = d * y
            t2.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t5.text = String(format: "%0.3f",temp2)
        }
        
        let myDouble2 = Double(num)
        if let d = myDouble2 {
            let temp : Double = d * z
            t3.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t6.text = String(format: "%0.3f",temp2)
        }
            }
    @IBAction func add8(_ sender: Any) {
        num += "8"
        number.text = num
        let myDouble = Double(num)
        if let d = myDouble {
            let temp : Double = d * x
            t1.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t4.text = String(format: "%0.3f",temp2)
        }
        
        let myDouble1 = Double(num)
        if let d = myDouble1 {
            let temp : Double = d * y
            t2.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t5.text = String(format: "%0.3f",temp2)
        }
        
        let myDouble2 = Double(num)
        if let d = myDouble2 {
            let temp : Double = d * z
            t3.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t6.text = String(format: "%0.3f",temp2)
        }    }
    @IBAction func add9(_ sender: Any) {
        num += "9"
        number.text = num
        let myDouble = Double(num)
        if let d = myDouble {
            let temp : Double = d * x
            t1.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t4.text = String(format: "%0.3f",temp2)
        }
        
        let myDouble1 = Double(num)
        if let d = myDouble1 {
            let temp : Double = d * y
            t2.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t5.text = String(format: "%0.3f",temp2)
        }
        
        let myDouble2 = Double(num)
        if let d = myDouble2 {
            let temp : Double = d * z
            t3.text = String(format: "%0.3f",temp)
            
            let temp2 : Double = temp + d
            t6.text = String(format: "%0.3f",temp2)
        }
    }
    
    
}


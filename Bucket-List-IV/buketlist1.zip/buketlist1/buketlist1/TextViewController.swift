//
//  AddTextViewController.swift
//  buketlist1
//
//  Created by administrator on 25/10/2021.
//

import UIKit

class TextViewController: UIViewController {
    var delog: ViewController?
    var dectionry : NSDictionary?
    var indexP : IndexPath?
    @IBOutlet weak var TextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        TextField.text = dectionry?.value(forKey: "objective") as? String
    }
    

    @IBAction func doSomthing(_ sender: Any) {
        let NewText = TextField.text!
        
        if(dectionry == nil){
        TaskModel.addTaskWithObjective(objective: NewText, completionHandler: {
            data, response, error in
            if data != nil {
                do {
                    let tasks = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
                    
                    DispatchQueue.main.async {
                        self.delog?.task.append(tasks)
                        self.delog?.tabelview.reloadData()
                        let _ = self.navigationController?.viewControllers.popLast()
                  }
                    
                }
               catch {
                  print("Something went wrong")
              }
            }
           
  })
        } else {
            dectionry?.setValue(NewText, forKey: "objective")
            
            
            TaskModel.updateTaskWithObjective(objective: dectionry!, completionHandler: {
                data, response, error in
                if data != nil {
                    do {
                        let task = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
                        
                        DispatchQueue.main.async {
                            self.delog?.task[self.indexP!.row] = task
                            self.delog?.tabelview.reloadData()
                            //let _ = self.navigationController?.viewControllers.popLast()
                      }
                        
                    }
                   catch {
                      print("Something went wrong")
                  }
                }
               
      })
        }
        
        
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

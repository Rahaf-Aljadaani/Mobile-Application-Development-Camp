//
//  ViewController.swift
//  dolist
//
//  Created by administrator on 15/10/2021.
//

import UIKit
import CoreData
class ViewController: UIViewController , UITableViewDataSource{
    //page 1
    @IBOutlet weak var coverText: UILabel!
    @IBOutlet weak var mainText: UILabel!
    @IBOutlet weak var dateText: UILabel!
    @IBOutlet weak var checkIcon: UIButton!
    @IBOutlet weak var tabelView: UITableView!
    var items : [Database] = []
    
    
    //page 2
    
    @IBOutlet weak var tiatel: UITextField!
    
    @IBOutlet weak var details: UITextField!
    @IBOutlet weak var dateInfo: UIDatePicker!
    
    @IBOutlet weak var labeltext: UILabel!
    
    //,,,,,,,,,
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        readItem();
        if tabelView != nil {
            tabelView.dataSource = self
           tabelView.delegate = self
           tabelView.reloadData()
        }
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIInputViewController.dismissKeyboard))
   // Do any additional setup after loading the view.
   view.addGestureRecognizer(tap)
    }
    @objc func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    
    //MARK:- table view staff
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count  // returning the number  of elements in  data array
    }

func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

    let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
   // coverText.text = items[indexPath.row].tital
    //mainText.text = items[indexPath.row].text
   // dateText.text = items[indexPath.row].date as! String
    
    cell.textLabel?.text = items[indexPath.row].tital
      return cell
  }

func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    let cell = tableView.cellForRow(at: indexPath)
    cell?.contentView.backgroundColor = UIColor.blue
    print("Section: \(indexPath.section) and Row: \(indexPath.row)")
    
  // item.remove(at: indexPath.row)
    tableView.reloadData()
}
    
    //MARK:-
    
    @IBAction func addItems(_ sender: Any) {
        if let x = tiatel.text{
            creatItem(name: x)
        }
    }
  
    
    // MARK: - coreData part
 
    func getContext () -> NSManagedObjectContext{
        let delegat = UIApplication.shared.delegate as! AppDelegate
        return delegat.persistentContainer.viewContext
    }
    
    
    func creatItem (name: String){
        let context = getContext()
        let item = Database.init(context: context)
        item.text = name
        do {
       //     coverText.text = name
            
            //coverText.text = name
            try context.save()
            
        } catch {
            print(error)
        }
    }
    
    func updateItem (newName: String){
        let context  = getContext()
        let requast = NSFetchRequest<NSFetchRequestResult>.init(entityName: "Itemes")
        do{
            let resalt = try context.fetch(requast)
            let item = resalt as! Database
         //   item.name = newName
            try context.save()
        }
        catch{
            
            print(error)
        }
    }
    
    func readItem (){
        let context  = getContext()
        let requast = NSFetchRequest<NSFetchRequestResult>.init(entityName: "Itemes")
        do{
            let resalt = try context.fetch(requast)
            let item = resalt as! Database
            items.append(item)
            tabelView.reloadData()
         //   itemList.append(item)
        //    label.text = item.name

        }
        catch{
            print(error)
        }
    }
    
    func deletItem (){
        let context  = getContext()
        let requast = NSFetchRequest<NSFetchRequestResult>.init(entityName: "Itemes")
        do{
            let resalt = try context.fetch(requast)
            let item = resalt as! Database
        //    item.name = ""
            
        }
        catch{
            print(error)
        }
        func readAllData(){
            do {
                let itemList = try context.fetch(Database.fetchRequest())
            }
            catch {
                print("Error")
            }
        }
    }
    
}


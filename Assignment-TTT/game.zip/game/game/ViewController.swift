//
//  ViewController.swift
//  game
//
//  Created by administrator on 30/09/2021.
//

import UIKit

class ViewController: UIViewController {
    var counter : Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var b1: UIButton!
    @IBOutlet weak var b2: UIButton!
    @IBOutlet weak var b3: UIButton!
    @IBOutlet weak var b4: UIButton!
    @IBOutlet weak var b5: UIButton!
    @IBOutlet weak var b6: UIButton!
    @IBOutlet weak var b7: UIButton!
    @IBOutlet weak var b8: UIButton!
    @IBOutlet weak var b9: UIButton!
    
    
    
    func runGame(_ sender: UIButton) {
        counter += 1
        if (counter % 2 == 0){
            sender.backgroundColor = UIColor.red
        }
        else{
            sender.backgroundColor = UIColor.blue
        }
    }
    
    
    @IBAction func sendb1(_ sender: Any) {
        runGame(b1)
    }
    @IBAction func sendb2(_ sender: Any) {
        runGame(b2)    }
    @IBAction func sendb3(_ sender: Any) {
        runGame(b3)    }
    @IBAction func sendb4(_ sender: Any) {
        runGame(b4)    }
    @IBAction func sendb5(_ sender: Any) {
        runGame(b5)    }
    @IBAction func sendb6(_ sender: Any) {
        runGame(b6)    }
    @IBAction func sendb7(_ sender: Any) {
        runGame(b7)    }
    @IBAction func sendb8(_ sender: Any) {
        runGame(b8)    }
    @IBAction func sendb9(_ sender: Any) {
        runGame(b9)    }
 
    
    
    @IBAction func again(_ sender: Any) {
        b1.backgroundColor = UIColor.gray
        b2.backgroundColor = UIColor.gray
        b3.backgroundColor = UIColor.gray
        b4.backgroundColor = UIColor.gray
        b5.backgroundColor = UIColor.gray
        b6.backgroundColor = UIColor.gray
        b7.backgroundColor = UIColor.gray
        b8.backgroundColor = UIColor.gray
        b9.backgroundColor = UIColor.gray

    }
    
}


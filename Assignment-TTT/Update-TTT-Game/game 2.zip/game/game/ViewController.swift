//
//  ViewController.swift
//  game
//
//  Created by administrator on 30/09/2021.
//

import UIKit

class ViewController: UIViewController {
    var counter : Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var b1: UIButton!
    @IBOutlet weak var b2: UIButton!
    @IBOutlet weak var b3: UIButton!
    @IBOutlet weak var b4: UIButton!
    @IBOutlet weak var b5: UIButton!
    @IBOutlet weak var b6: UIButton!
    @IBOutlet weak var b7: UIButton!
    @IBOutlet weak var b8: UIButton!
    @IBOutlet weak var b9: UIButton!
    
    
    // 1 2 3
    // 4 5 6
   // 7 8 9
   // 1 4 7
   // 2 5 8
   // 3 6 9
   // 1 5 9
   // 3 5 7
    var arrPlayer1 : [Int] = [0,0,0,0,0,0,0,0]
    var arrPlayer2 : [Int] = [0,0,0,0,0,0,0,0]
    var finich: Int = 0

    @IBOutlet weak var resalt: UILabel!
    
    
    func runGame(_ sender: UIButton) {
            cheackIfHeWin()
        if (counter % 2 == 0){
            sender.backgroundColor = UIColor.red
        }
        else{
            sender.backgroundColor = UIColor.blue
        }
    }
    
    func cheackIfHeWin(){
        
        if(counter % 2 == 0){
            for i in arrPlayer2 {
                if i == 3 {
                    resalt.text = "Player2 is win "
                }
            }
        }
        else if (counter % 2 != 0){
            for i in arrPlayer1 {
                if i == 3 {
                    resalt.text = "Player1 is win "
                }
            }
        }
        else{
            resalt.text = "No winer"
        }
        
       
    }
    
    @IBAction func sendb1(_ sender: Any) {
        counter += 1
        if(counter % 2 != 0){
            arrPlayer1[0] += 1
            arrPlayer1[3] += 1
            arrPlayer1[6] += 1
        }
        else{
            arrPlayer2[0] += 1
            arrPlayer2[3] += 1
            arrPlayer2[6] += 1
        }
      
        finich += 1
        runGame(b1)
    }
    @IBAction func sendb2(_ sender: Any) {
        counter += 1
        if(counter % 2 != 0){
            arrPlayer1[0] += 1
            arrPlayer1[4] += 1
        }
        else{
            arrPlayer2[0] += 1
            arrPlayer2[4] += 1
        }
        finich += 1
        runGame(b2)    }
    @IBAction func sendb3(_ sender: Any) {
       counter += 1
         if(counter % 2 != 0){
            arrPlayer1[0] += 1
            arrPlayer1[5] += 1
            arrPlayer1[7] += 1
        }
        else{
            arrPlayer2[0] += 1
            arrPlayer2[5] += 1
            arrPlayer2[7] += 1
        }
    
        finich += 1
        runGame(b3)    }
    @IBAction func sendb4(_ sender: Any) {
    counter += 1
        if(counter % 2 != 0){
            arrPlayer1[1] += 1
            arrPlayer1[3] += 1
        }
        else{
            arrPlayer2[1] += 1
            arrPlayer2[3] += 1
        }
      
        finich += 1
        runGame(b4)    }
    @IBAction func sendb5(_ sender: Any) {
        counter += 1
        if(counter % 2 != 0){
            arrPlayer1[1] += 1
            arrPlayer1[4] += 1
            arrPlayer1[6] += 1
            arrPlayer1[7] += 1
        }
        else{
            arrPlayer2[1] += 1
            arrPlayer2[4] += 1
            arrPlayer2[6] += 1
            arrPlayer2[7] += 1
        }
    
        finich += 1
        runGame(b5)    }
    @IBAction func sendb6(_ sender: Any) {
        counter += 1
        if(counter % 2 != 0){
            arrPlayer1[1] += 1
            arrPlayer1[5] += 1
        }
        else{
            arrPlayer2[1] += 1
            arrPlayer2[5] += 1
        }
  
        finich += 1
        runGame(b6)    }
    @IBAction func sendb7(_ sender: Any) {
        counter += 1
        if(counter % 2 != 0){
            arrPlayer1[2] += 1
            arrPlayer1[3] += 1
            arrPlayer1[7] += 1
        }
        else{
            arrPlayer2[2] += 1
            arrPlayer2[3] += 1
            arrPlayer2[7] += 1
        }

        finich += 1
        runGame(b7)    }
    @IBAction func sendb8(_ sender: Any) {
        if(counter % 2 != 0){
            arrPlayer1[2] += 1
            arrPlayer1[4] += 1
        }
        else{
            arrPlayer2[2] += 1
            arrPlayer2[4] += 1
        }
       // win3+=1
      //  win5+=1
        finich += 1
        runGame(b8)    }
    @IBAction func sendb9(_ sender: Any) {
        counter += 1
        if(counter % 2 != 0){
            arrPlayer1[2] += 1
            arrPlayer1[5] += 1
            arrPlayer1[6] += 1
        }
        else{
            arrPlayer2[2] += 1
            arrPlayer2[5] += 1
            arrPlayer2[6] += 1
        }
    
        finich += 1
        runGame(b9)    }
 
    
    
    @IBAction func again(_ sender: Any) {
        b1.backgroundColor = UIColor.gray
        b2.backgroundColor = UIColor.gray
        b3.backgroundColor = UIColor.gray
        b4.backgroundColor = UIColor.gray
        b5.backgroundColor = UIColor.gray
        b6.backgroundColor = UIColor.gray
        b7.backgroundColor = UIColor.gray
        b8.backgroundColor = UIColor.gray
        b9.backgroundColor = UIColor.gray
        finich = 0
        arrPlayer1 = [0,0,0,0,0,0,0,0]
        arrPlayer2 = [0,0,0,0,0,0,0,0]
        resalt.text = ""
    }
    
}


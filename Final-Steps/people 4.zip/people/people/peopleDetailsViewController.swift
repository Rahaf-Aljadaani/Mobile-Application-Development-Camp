

import UIKit

class peopleDetailsViewController: UIViewController {

    var passedPerson : NSDictionary!
    
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var gender: UILabel!
    @IBOutlet weak var birthday: UILabel!
    @IBOutlet weak var mass: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    @IBAction func unwind(_ sender: UIStoryboard){
        
       
        name.text = passedPerson["name"] as! String
        gender.text = passedPerson["gender"] as! String
        birthday.text = passedPerson["birth_year"] as! String
        mass.text = passedPerson["mass"] as! String
    }


}



import UIKit

class moivesDetailsViewController: UIViewController {

    @IBOutlet weak var Rdate: UILabel!
    
    @IBOutlet weak var tatile: UILabel!
    
    @IBOutlet weak var opening: UILabel!
    @IBOutlet weak var dirctor: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }


}

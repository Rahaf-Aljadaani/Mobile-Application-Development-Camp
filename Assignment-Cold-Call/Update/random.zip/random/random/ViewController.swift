//
//  ViewController.swift
//  random
//
//  Created by administrator on 29/09/2021.
//

import UIKit

class ViewController: UIViewController {
 var names: [String] = ["Rahaf","kiven","Danny","Ashish"]//....
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }


    @IBOutlet weak var number: UILabel!
    @IBOutlet weak var place: UILabel!
    @IBAction func boutton(_ sender: Any) {
        place.text = names[Int.random(in: 0..<4)]
        let x : Int = Int.random(in: 1...5)
        if(x == 1 || x == 2){
            number.textColor = UIColor.red
            number.text = String(x)}
        else if (x == 3 || x == 4){
            number.textColor = UIColor.orange
            number.text = String(x)        }
        else {
            number.textColor = UIColor.green
            number.text = String(x)
        }
        
    }
}



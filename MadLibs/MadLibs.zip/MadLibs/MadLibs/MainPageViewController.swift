//
//  MainPageViewController.swift
//  MadLibs
//
//  Created by administrator on 08/10/2021.
//

import UIKit

class MainPageViewController: UIViewController {
  //  var Adjactive : String?
   // var Verb1 : String?
   // var Verb2 : String?
   // var Noun : String?
    
   // @IBOutlet weak var outputLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

      //  outputLabel.text = "We are having a perfecty \(Adjactive) time now. Later we will \(Verb1) and \(Verb2) in the \(Noun)"
        
    }
    
  //  @IBAction func WriteButton(_ sender: Any) {
    //    navigationController?.pushViewController(writingPageViewController, animated: <#T##Bool#>)
        
    //}
    
    
 


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

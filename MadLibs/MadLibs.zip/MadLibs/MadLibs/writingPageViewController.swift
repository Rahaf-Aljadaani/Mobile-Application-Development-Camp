//
//  writingPageViewController.swift
//  MadLibs
//
//  Created by administrator on 08/10/2021.
//

import UIKit

protocol prssesData : AnyObject {
    func sendData( Adj: String , v1: String , v2: String , Noun: String)
}

class writingPageViewController: UIViewController  {
    @IBOutlet weak var AdjLabel: UITextField!
    @IBOutlet weak var Varb1Label: UITextField!
    @IBOutlet weak var Varb2Label: UITextField!
    @IBOutlet weak var NounLabel: UITextField!
    var text1 :String = ""
//    weak var delegate : prssesData?
    override func viewDidLoad() {
        super.viewDidLoad()
        //Looks for single or multiple taps.
             let tap = UITapGestureRecognizer(target: self, action: #selector(UIInputViewController.dismissKeyboard))
        // Do any additional setup after loading the view.
        view.addGestureRecognizer(tap)
        //delegate?.sendData(Adj: AdjLabel.text!, v1: Varb1Label.text!, v2: Varb2Label.text!, Noun: NounLabel.text!)
        
    }
    
override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destination = segue.destination as! ViewController
    text1 = "We are having a perfecty \(AdjLabel.text!) time now. Later we will \(Varb1Label.text!) and \(Varb2Label.text!) in the \( NounLabel.text!)"
        destination.sentens = text1
    destination.didGoToWritePage = true
    }
    
    
    @objc func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    @IBAction func back(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    

    
}



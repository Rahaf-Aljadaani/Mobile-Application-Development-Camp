//
//  ViewController.swift
//  MadLibs
//
//  Created by administrator on 08/10/2021.
//

import UIKit

class ViewController: UIViewController{
    var sentens : String?
    var didGoToWritePage : Bool? = false
    
    @IBOutlet weak var outputLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
     

        
    }

    @IBAction func unwind(_ sender: UIStoryboard){
        
        if(didGoToWritePage == true){
         outputLabel.text = sentens
             didGoToWritePage = false
         }
    }

}

   



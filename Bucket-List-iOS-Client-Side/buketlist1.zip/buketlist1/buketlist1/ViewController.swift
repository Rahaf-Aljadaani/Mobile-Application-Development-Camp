//
//  ViewController.swift
//  buketlist1
//
//  Created by administrator on 24/10/2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tabelview: UITableView!
    var task = [NSDictionary]()
        override func viewDidLoad() {
            super.viewDidLoad()
            TaskModel.getAllTasks() {
                      data, response, error in
                      do {
                          if let tasks = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSArray {
                            print(tasks)
                            for task in tasks {
                                    print(task)
                                    self.task.append(task as! NSDictionary)
                                
                            }
                        }
                        DispatchQueue.main.async {
                           self.updateUI()
                           //self.tableView.reloadData()
                        }
                    } catch {
                        print("Something went wrong")
                    }
            }
            tabelview.dataSource = self
         
            // Do any additional setup after loading the view.
        }
    
    func updateUI() {
        DispatchQueue.main.async {
            print("Aceesing the main UI thread")
            self.tabelview.reloadData()
        }
    }


}


extension ViewController: UITableViewDataSource {
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        // if we return - sections we won't have any sections to put our rows in
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return task.count  // returning the number  of elements in  data array
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = task[indexPath.row]["objective"]! as! String
        
        return cell
    }
    
   
    
}

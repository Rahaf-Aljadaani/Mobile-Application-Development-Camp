//
//  TaskViewController.swift
//  bucketListNew
//
//  Created by administrator on 24/10/2021.
//

import UIKit

class TaskViewController: UITableViewController {
var task = [NSDictionary]()
    override func viewDidLoad() {
        super.viewDidLoad()
        Taskmodel.getAllTasks(completionHandler: {
            data, response, error in
                do {
                    if let TaskResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSArray {
                        
                            for task in TaskResult {
                                self.task.append(task as! NSDictionary)
                            
                        }
                    }
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                       //self.tableView.reloadData()
                    }
                } catch {
                    print("Something went wrong")
                }
        })
     
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    override func numberOfSections(in tableView: UITableView) -> Int {
        // if we return - sections we won't have any sections to put our rows in
        return 1
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return task.count  // returning the number  of elements in  data array
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = task[indexPath.row]["objective"]! as! String
        
        return cell
    }



}

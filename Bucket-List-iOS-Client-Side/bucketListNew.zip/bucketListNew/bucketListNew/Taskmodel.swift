//
//  Taskmodel.swift
//  bucketListNew
//
//  Created by administrator on 24/10/2021.
//

import Foundation
class Taskmodel {
    static func getAllTasks(completionHandler: @escaping(_ date: Date?, _ response: URLResponse?, _ error: Error?) -> Void){
        
        let url = URL(string: "http://localhost:3000/tasks")
        let session = URLSession.shared
        let task = session.dataTask(with: url, completionHandler: completionHandler)
        task.resume()
    }
}

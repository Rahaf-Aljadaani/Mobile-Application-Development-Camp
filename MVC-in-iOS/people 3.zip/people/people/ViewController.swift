//
//  ViewController.swift
//  people
//
//  Created by administrator on 17/10/2021.
//

import UIKit

class ViewController: UIViewController {
    // Hardcoded data for now
    @IBOutlet weak var tabelView: UITableView!
    var people : [String ] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        StarWarsModel.getAllPeople(completionHandler: { // passing what becomes "completionHandler" in the 'getAllPeople' function definition in StarWarsModel.swift
                 data, response, error in
                     do {
                         // Try converting the JSON object to "Foundation Types" (NSDictionary, NSArray, NSString, etc.)
                         if let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary {
                             if let results = jsonResult["results"] as? NSArray {
                                 for person in results {
                                     let personDict = person as! NSDictionary
                                     self.people.append(personDict["name"]! as! String)
                                 }
                             }
                         }
                         DispatchQueue.main.async {
                            self.updateUI()
                            //self.tableView.reloadData()
                         }
                     } catch {
                         print("Something went wrong")
                     }
             })
          
        
        
        //------------------
       
        
        //--------------------
        tabelView.dataSource = self
        
    }
    func updateUI() {
        DispatchQueue.main.async {
            print("Aceesing the main UI thread")
            self.tabelView.reloadData()
        }
    }
    
}


extension ViewController: UITableViewDataSource {
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        // if we return - sections we won't have any sections to put our rows in
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return people.count  // returning the number  of elements in  data array
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = people[indexPath.row]
        
        return cell
    }
    
    
}

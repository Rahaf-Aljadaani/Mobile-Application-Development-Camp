//
//  ViewController.swift
//  people
//
//  Created by administrator on 17/10/2021.
//

import UIKit

class ViewController: UIViewController {
    // Hardcoded data for now
    @IBOutlet weak var tabelView: UITableView!
    var people : [String ] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        let url = URL(string: "https://swapi.dev/api/people/?format=json")
               // create a URLSession to handle the request tasks
               let session = URLSession.shared
               // create a "data task" to make the request and run completion handler
               let task = session.dataTask(with: url!, completionHandler: {
                   // see: Swift closure expression syntax
                   data, response, error in
                   // data -> JSON data, response -> headers and other meta-information, error-> if one occurred
                   // "do-try-catch" blocks execute a try statement and then use the catch statement for errors
                   do {
                       // try converting the JSON object to "Foundation Types" (NSDictionary, NSArray, NSString, etc.)
                    
                    if let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary {
                     // Why do we need to optionally unwrap jsonResult["results"]
                     // Try it without the optional unwrapping and you'll see that the value is actually an optional
                     if let results = jsonResult["results"] {
                             print(results)
                        
                        if let result = jsonResult["results"] as? NSArray {

                        for person in result {
                                                   let personDict = person as! NSDictionary
                                                   let personName = personDict["name"] as! String
                                                   self.people.append(personName)
                                               }
                        }
                        
                            }
                    }
                    
                    
                    self.updateUI()

                    
                   } catch {
                       print(error)
                   }
               })
               // execute the task and then wait for the response
               // to run the completion handler. This is async!
               task.resume()
        
       
        // Do any additional setup after loading the view, typically from a nib.
        tabelView.dataSource = self
        
    }
    func updateUI() {
         DispatchQueue.main.async {
             print("Aceesing the main UI thread")
            self.tabelView.reloadData()
         }
     }

}


extension ViewController: UITableViewDataSource {
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
     func numberOfSections(in tableView: UITableView) -> Int {
        // if we return - sections we won't have any sections to put our rows in
        return 1
    }
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return people.count  // returning the number  of elements in  data array
        }
   
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

          let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
          cell.textLabel?.text = people[indexPath.row]
        
          return cell
      }
    

  }


/*{

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        // specify the url that we will be sending the GET request to
              let url = URL(string: "https://swapi.dev/api/people/?format=json")
              // create a URLSession to handle the request tasks
              let session = URLSession.shared
              // create a "data task" to make the request and run completion handler
              let task = session.dataTask(with: url!, completionHandler: {
                  // see: Swift closure expression syntax
                  data, response, error in
                  // data -> JSON data, response -> headers and other meta-information, error-> if one occurred
                  // "do-try-catch" blocks execute a try statement and then use the catch statement for errors
                  do {
                      // try converting the JSON object to "Foundation Types" (NSDictionary, NSArray, NSString, etc.)
                      if let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary {
                          print(jsonResult)
                      }
                  } catch {
                      print(error)
                  }
              })
              // execute the task and then wait for the response
              // to run the completion handler. This is async!
              task.resume()
        if let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary {
            
            if let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary {
             // Why do we need to optionally unwrap jsonResult["results"]
             // Try it without the optional unwrapping and you'll see that the value is actually an optional
             if let results = jsonResult["results"] {
                     print(results)
                    }
            }
            
    }
    }
    
    if let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary {
        // Why do we need to optionally unwrap jsonResult["results"]
        // Try it without the optional unwrapping and you'll see that the value is actually an optional
        if let results = jsonResult["results"] {
        // coercing the results object as an NSArray and then storing that in resultsArray
            let resultsArray = results as! NSArray
            // now we can run NSArray methods like count and firstObject
            print(resultsArray.count)
            print(resultsArray[0])
            print(resultsArray.firstObject)
        }
    }


}*/

